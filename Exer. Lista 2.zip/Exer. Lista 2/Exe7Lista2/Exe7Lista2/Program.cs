﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe7Lista2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a;
            int b;
            int c;

            Console.Write("Escreva o primeiro valor: ");
            a = int.Parse(Console.ReadLine());
            Console.Write("Escreva o segundo valor: ");
            b = int.Parse(Console.ReadLine());
            Console.Write("Escreva o segundo valor: ");
            c = int.Parse(Console.ReadLine());

            if (a + b > c && a + c > b && b + c > a)
                if (a == b && a == c)
                    Console.WriteLine("Triângulo Equilátero");
                else
                if (a == b || a == c || b == c)
                    Console.WriteLine("Triângulo Isósceles");
                else
                    Console.WriteLine("Triângulo Escaleno");
            else
                Console.WriteLine("Não Formam Triângulo");
        }
    }
}
