﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe6Lista2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double a;
            double p;
            double r;
            double c;
            
            Console.WriteLine("Escreva Valor de sua Altura.");
            a = Double.Parse(Console.ReadLine());

            Console.WriteLine("Escreva Valor do seu Peso.");
            p = Double.Parse(Console.ReadLine());

            c = a * a;
            r = p / c;

            if (r < 20)
                Console.WriteLine("Abaixo do Peso");
            else 
             if (r >= 25)
                Console.WriteLine("Acima do Peso.");
            else 
             if (r < 25)
                Console.WriteLine("Peso Ideal.");
        }

    }
}
