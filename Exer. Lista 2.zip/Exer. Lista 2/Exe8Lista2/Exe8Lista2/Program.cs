﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe8Lista2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int a;
            int b;
            int c;
           
            Console.Write("Escreva o primeiro valor: ");
            a = int.Parse(Console.ReadLine());
            Console.Write("Escreva o segundo valor: ");
            b = int.Parse(Console.ReadLine());
            Console.Write("Escreva o terceiro valor: ");
            c = int.Parse(Console.ReadLine());

            if (((b * b) + (c * c)) == (a * a))
                Console.WriteLine("Ele é um Triângulo Retângulo");
            else
                Console.WriteLine("Ele não é um Triângulo Retângulo");
                

        }
    }
}
