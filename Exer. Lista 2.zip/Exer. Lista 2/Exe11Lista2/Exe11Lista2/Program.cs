﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exe11Lista2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double P1;          
            double R;

            Console.Write("Escreva o Valor da P1: ");
            P1 = Double.Parse(Console.ReadLine());
            
            R = ((5 * 3) - P1);
           
            Console.WriteLine("Nota essencial para P2 é {0}", R);
          
        }
    }
}
